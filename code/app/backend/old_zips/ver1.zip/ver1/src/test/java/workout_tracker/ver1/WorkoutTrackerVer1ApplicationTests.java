package workout_tracker.ver1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkoutTrackerVer1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
