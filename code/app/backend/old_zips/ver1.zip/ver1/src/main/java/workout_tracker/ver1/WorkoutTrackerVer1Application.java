package workout_tracker.ver1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkoutTrackerVer1Application {

	public static void main(String[] args) {
		SpringApplication.run(WorkoutTrackerVer1Application.class, args);
	}

}
